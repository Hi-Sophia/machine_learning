#by cangye@hotmail.com
#引入库
from tensorflow.examples.tutorials.mnist import input_data
# from tensorflow_core.examples.tutorials.mnist import input_data
# from tensorflow_core.contrib.learn.python.learn.datasets.mnist import read_data_sets

'''
60000行的训练数据集（mnist.train）和10000行的测试数据集（mnist.test）

主要结构为：输入-卷积层-池化层-卷积层-池化层-全连接层-输出
卷积：可以看做是提取特征的过程 【卷积核】
池化：用来把卷积结果进行压缩，进一步减少全连接时的连接数。
池化有两种：
一种是最大池化，在选中区域中找最大的值作为抽样后的值；
一种是平均值池化，把选中的区域中的平均值作为抽样后的值

label：标签是指我们期望网络返回的结果。
'''
import tensorflow as tf
#获取数据
mnist = input_data.read_data_sets("../data/", one_hot=True)
#构建网络模型
#x，label分别为图形数据和标签数据
#None 代表任意长度均可，这是因为我们在训练的过程中可能输入的是多个样本进行训练
x = tf.placeholder(tf.float32, [None, 784])
label = tf.placeholder(tf.float32, [None, 10])

#构建单层网络中的权值和偏置
W = tf.Variable(tf.zeros([784, 10]))
b = tf.Variable(tf.zeros([10]))

#本例中sigmoid激活函数
y = tf.nn.sigmoid(tf.matmul(x, W) + b)

#定义损失函数为欧氏距离
# loss = tf.reduce_mean(tf.square(y-label))  #是标量
with tf.variable_scope("loss"):
    #定义loss函数
    ce=tf.nn.softmax_cross_entropy_with_logits(labels=label, logits=y)
    loss = tf.reduce_mean(ce)

#用梯度迭代算法
train_step = tf.train.GradientDescentOptimizer(0.1).minimize(loss)

#用于验证
correct_prediction = tf.equal(tf.argmax(y, 1), tf.argmax(label, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

#定义会话
sess = tf.Session()
#初始化所有变量
sess.run(tf.global_variables_initializer())
#迭代过程
train_writer = tf.summary.FileWriter("mnist-logdir", sess.graph)

for itr in range(1000):
    batch_xs, batch_ys = mnist.train.next_batch(100)
    sess.run(train_step, feed_dict={x: batch_xs, label: batch_ys})

    if itr % 10 == 0:
        print("step:%6d  accuracy:"%itr, sess.run(accuracy, feed_dict={x: mnist.test.images,
                                        label: mnist.test.labels}))
################################绘图过程################################################
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
mpl.style.use('fivethirtyeight')
#获取W取值
W = sess.run(W.value())
#绘图过程
fig = plt.figure()
ax = fig.add_subplot(221)
ax.matshow(np.reshape(W[:,1],[28,28]), cmap=plt.get_cmap("Purples"))
ax = fig.add_subplot(222)
ax.matshow(np.reshape(W[:,2],[28,28]), cmap=plt.get_cmap("Purples"))
ax = fig.add_subplot(223)
ax.matshow(np.reshape(W[:,3],[28,28]), cmap=plt.get_cmap("Purples"))
ax = fig.add_subplot(224)
ax.matshow(np.reshape(W[:,4],[28,28]), cmap=plt.get_cmap("Purples"))
plt.show()